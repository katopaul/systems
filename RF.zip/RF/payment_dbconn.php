<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "online_db";

// Create connection
$conn_integration = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn_integration->connect_error) {
    error_log("Database connection failed: " . $conn_integration->connect_error);
    die("Payment system is currently unavailable. Please try again later.");
}

// Set character set
$conn_integration->set_charset("utf8mb4");

// Enable error reporting
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);