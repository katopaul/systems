<!DOCTYPE html>
<html lang="en">

<?php
include('header.php');
?>

<?php
include('navigation.php');
?>

<?php

//======================================== Cart Functions ============================================

function display_cart()
{
    $total = 0;
    $item_quantity = 0;

    //operation on session variable (associative array)
    foreach ($_SESSION as $name => $value) {
        if ($value > 0) {
            // Check if session name starts with "product_"
            if (substr($name, 0, 8) == "product_") {

                // Extract product_id from session name
                $length = strlen($name) - 8;
                $id = substr($name, 8, $length);

                $stmt = query("SELECT * FROM food_items WHERE food_id={$id}");
                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {

                    // Calculate subtotal of items
                    $sub = $row['food_price'] * $value;

                    // Total item quantity
                    $item_quantity += $value;

                    echo "
                        <tr class='text-center'>
                            <td class='product-remove'>
                                <a href='cart.php?delete={$row['food_id']}'><span class='icon-close'></span></a>&nbsp;&nbsp;
                            </td>

                            <td class='image-prod'>
                                <div class='img'><img class='img-responsive' width='90' src='admin/{$row['food_image']}' alt='320x150'></div>
                            </td>
                    
                            <td class='product-name'>
                                <h3>{$row['food_name']}</h3>
                                <p>{$row['short_description']}</p>
                            </td>

                            <td class='price'>৳ {$row['food_price']}</td>
                            <td class='price'>{$value}</td>
                            <td class='total'>৳ {$sub}</td>
                    
                            <td class='product-remove'>
                                <a href='cart.php?add={$row['food_id']}'><span class='icon-add'></span></a>&nbsp;&nbsp;
                                <a href='cart.php?remove={$row['food_id']}'><span class='icon-minus'></span></a>&nbsp;&nbsp;
                            </td>
                        </tr>";
                }

                // Accumulate the total amount of items
                $total += $sub;
                $_SESSION['item_total'] = $total;

                // Track total quantity of items
                $_SESSION['item_quantity'] = $item_quantity;
            }
        }
    }
}

function cart_system()
{
    // Handle item addition to the cart
    if (isset($_GET['add'])) {

        $stmt = query("SELECT * FROM food_items WHERE food_id={$_GET['add']}");
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {

            if ($row['quantity'] != $_SESSION['product_' . $_GET['add']]) { // Check if item is available
                $_SESSION['product_' . $_GET['add']] += 1;
                redirect("cart.php?success=item_add");
            } else {
                redirect("cart.php?error=not_available");
            }
        }
    }

    // Handle item removal from the cart
    if (isset($_GET['remove'])) {

        if ($_SESSION['product_' . $_GET['remove']] < 1) {
            redirect("cart.php?error=cart_empty");
        } else {
            $_SESSION['product_' . $_GET['remove']] -= 1;
            if ($_SESSION['product_' . $_GET['remove']] < 1) {
                unset($_SESSION['item_total']);
                unset($_SESSION['item_quantity']);
            }
            redirect("cart.php?success=item_removed");
        }
    }

    // Handle item deletion from the cart
    if (isset($_GET['delete'])) {

        $_SESSION['product_' . $_GET['delete']] = '0';
        unset($_SESSION['item_total']);
        unset($_SESSION['item_quantity']);
        redirect("cart.php?success=item_deleted");
    }

    display_cart();
}

//fixed variables
$Total_amount = 0;
$Discount = 0;
$Delivery_charge = 50;
$Vat = 100;
?>

<section class="ftco-section ftco-cart">
    <div class="container">
        <div class="row">
            <div class="col-md-12 ftco-animate">
                <div class="cart-list">
                    <table class="table">
                        <thead class="thead-primary">
                            <tr class="text-center">
                                <th>&nbsp;</th>
                                <th>&nbsp;</th>
                                <th>Product</th>
                                <th>Price</th>
                                <th>Quantity</th>
                                <th>Total</th>
                                <th>&nbsp;</th>
                                <th>&nbsp;</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php cart_system(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div class="row justify-content-end">
            <div class="mt-5 col col-lg-3 col-md-6 cart-wrap ftco-animate">
                <div class="mb-3 cart-total">
                    <h3>Cart Totals</h3>
                    <p class="d-flex">
                        <span>Subtotal</span>
                        <span>৳ <?php echo isset($_SESSION['item_total']) ? $_SESSION['item_total'] : '0'; ?></span>
                    </p>

                    <p class="d-flex">
                        <span>Quantity Bought</span>
                        <span><?php echo isset($_SESSION['item_quantity']) ? $_SESSION['item_quantity'] : '0'; ?></span>
                    </p>

                    <p class="d-flex">
                        <span>Discount</span>
                        <span>৳ <?php echo $Discount; ?></span>
                    </p>

                    <hr>
                    <p class="d-flex total-price">
                        <span>Total</span>
                        <span>৳
                            <?php
                            $Total_amount = $_SESSION['item_total'] + $Delivery_charge - $Discount + $Vat;
                            echo $Total_amount;
                            $_SESSION["total_amount"] = $Total_amount;
                            ?>
                        </span>
                    </p>
                </div>

                <?php if (is_logged_in() == true) : ?>
                    <p class="text-center"><a href="checkout.php" class="px-4 py-3 btn btn-primary">Proceed to Checkout</a></p>
                <?php endif; ?>

                <?php if (is_logged_in() == false) : ?>
                    <p class="text-center"><a href="#" class="px-4 py-3 btn btn-danger">Login to Add Items to Cart!</a></p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>

<?php
include('footer.php');
?>

<div id="ftco-loader" class="show fullscreen">
    <svg class="circular" width="48px" height="48px">
        <circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee" />
        <circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00" />
    </svg>
</div>

<script src="js/jquery.min.js"></script>
<script src="js/jquery-migrate-3.0.1.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="js/jquery.waypoints.min.js"></script>
<script src="js/jquery.stellar.min.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/jquery.magnific-popup.min.js"></script>
<script src="js/aos.js"></script>
<script src="js/jquery.animateNumber.min.js"></script>
<script src="js/bootstrap-datepicker.js"></script>
<script src="js/jquery.timepicker.min.js"></script>
<script src="js/scrollax.min.js"></script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&amp;sensor=false"></script>
<script src="js/google-map.js"></script>
<script src="js/main.js"></script>
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13"></script>
<script>
    window.dataLayer = window.dataLayer || [];

    function gtag() {
        dataLayer.push(arguments);
    }
    gtag('js', new Date());

    gtag('config', 'UA-23581568-13');
</script>

</body>
</html>
