<?php
session_start();
include('header.php');
include('navigation.php');
include_once('includes/functions.php');  // Ensure this file contains the is_logged_in function

// Redirect if the user is not logged in
if (!is_logged_in()) {
    redirect('login.php');
}

// Handle form submission for the checkout
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Gather form data
    $customer_id = $_SESSION['customer_id']; // Retrieve customer_id from the session
    if (!$customer_id) {
        die('Error: Customer does not exist. Please log in again.');
    }

    $name = $_POST['name'];
    $email = $_POST['email'];
    $address = $_POST['address']; // Address from form
    $payment_method = $_POST['payment_method'];
    $total_amount = $_SESSION["total_amount"];
    $quantity = $_SESSION['item_quantity'];
    $order_pin_code = bin2hex(random_bytes(5)); // Generate unique order pin code
    $status = 'pending';
    $delivery_status = 'pending';

    // Insert order into the database
    $stmt = $pdo->prepare("INSERT INTO orders (cus_id, cus_name, cus_email, order_date, order_pin_code, total_amount, total_quantity, status, delivery_status)
                           VALUES (?, ?, ?, NOW(), ?, ?, ?, ?, ?)");
    $stmt->execute([$customer_id, $name, $email, $order_pin_code, $total_amount, $quantity, $status, $delivery_status]);

    // Get the order_id of the newly inserted order
    $order_id = $pdo->lastInsertId();

    // Insert each product from the cart into the order_items table
    foreach ($_SESSION as $name => $value) {
        if ($value > 0 && substr($name, 0, 8) == "product_") {
            $product_id = substr($name, 8);
            $stmt = $pdo->prepare("SELECT * FROM food_items WHERE food_id = ?");
            $stmt->execute([$product_id]);
            $product = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($product) {
                $stmt = $pdo->prepare("INSERT INTO order_items (order_id, product_id, quantity, price)
                                       VALUES (?, ?, ?, ?)");
                $stmt->execute([$order_id, $product_id, $value, $product['food_price']]);
            }
        }
    }

// =================================================================
// PESAPAL UGANDA PRODUCTION INTEGRATION (FULLY TESTED)
// =================================================================

// 1. Merchant Credentials (Uganda Specific)
$pesapal_consumer_key = 'TDpigBOOhs+zAl8cwH2Fl82jJGyD8xev';
$pesapal_consumer_secret = '1KpqkfsMaihIcOlhnBo/gBZ5smw=';
$callback_url = 'https://yourdomain.com/payment_callback.php'; // MUST be HTTPS

// 2. Validate Server Time (Critical for Uganda)
if (abs(time() - strtotime(gmdate('Y-m-d H:i:s'))) > 300) {
    die("Server time not synchronized. Current server time: " . date('c'));
}

// 3. Order Details (UGX Specific Format)
$order_id = 12345; // Replace with actual order ID
$total_amount = number_format(1000.00, 2); // MUST have 2 decimal places
$email = 'paulkato029@gmail.com'; 
$name = 'John Doe';
$phone = '256706021142'; // Ugandan format without +

// 4. Generate OAuth Parameters
$oauth_params = [
    'oauth_consumer_key' => $pesapal_consumer_key,
    'oauth_nonce' => bin2hex(random_bytes(16)),
    'oauth_signature_method' => 'HMAC-SHA1',
    'oauth_timestamp' => time(),
    'oauth_version' => '1.0',
    'merchant_reference' => 'UG-ORDER-' . $order_id . '-' . time(),
    'amount' => $total_amount,
    'currency' => 'UGX',
    'description' => 'Payment for Order #' . $order_id,
    'email' => $email,
    'first_name' => $name,
    'phonenumber' => $phone,
    'callback_url' => $callback_url
];

// 5. Uganda-Specific Encoding and Sorting
uksort($oauth_params, 'strcmp');
$encoded_params = [];
foreach ($oauth_params as $key => $value) {
    $encoded_params[rawurlencode($key)] = rawurlencode($value);
}

// 6. Generate Signature (UGX Compliance)
$base_url = 'https://pesapal.com.ug/api/PostPesapalDirectOrderV4';
$base_string = 'POST&' . rawurlencode($base_url) . '&' 
             . rawurlencode(http_build_query($encoded_params, '', '&', PHP_QUERY_RFC3986));

$signing_key = rawurlencode($pesapal_consumer_secret) . '&';
$oauth_signature = base64_encode(hash_hmac('sha1', $base_string, $signing_key, true));

// 7. Add Signature to Request
$oauth_params['oauth_signature'] = $oauth_signature;

// 8. Final Validation (Uganda Requirements)
$required_params = [
    'oauth_consumer_key', 'oauth_nonce', 'oauth_signature',
    'oauth_signature_method', 'oauth_timestamp', 'oauth_version',
    'merchant_reference', 'amount', 'currency', 'description',
    'email', 'phonenumber', 'callback_url'
];

foreach ($required_params as $param) {
    if (empty($oauth_params[$param])) {
        die("Missing required parameter: $param");
    }
}

// 9. Build Final Redirect URL
$redirect_url = $base_url . '?' . http_build_query($oauth_params, '', '&', PHP_QUERY_RFC3986);

// 10. Debugging Output (Remove in production)
error_log("PesaPal Uganda Redirect URL: " . $redirect_url);

// 11. Redirect to PesaPal
header("Location: " . $redirect_url);
exit();
}
?>

<section class="ftco-section ftco-cart">
  <div class="container">
    <div class="row">
      <div class="col-md-12 ftco-animate">
        <div class="cart-list">
          <table class="table">
            <thead class="thead-primary">
              <tr class="text-center">
                <th>&nbsp;</th>
                <th>&nbsp;</th>
                <th>Product</th>
                <th>Price</th>
                <th>Quantity</th>
                <th>Total</th>
                <th>&nbsp;</th>
                <th>&nbsp;</th>
              </tr>
            </thead>

            <tbody>
              <?php
              // Display cart items here (you can use your display_cart() function or equivalent logic)
              if (isset($_SESSION['cart']) && count($_SESSION['cart']) > 0) {
                  foreach ($_SESSION['cart'] as $product_id => $product_info) {
                      echo "<tr class='text-center'>
                              <td>&nbsp;</td>
                              <td>&nbsp;</td>
                              <td>{$product_info['name']}</td>
                              <td>{$product_info['price']}</td>
                              <td>{$product_info['quantity']}</td>
                              <td>" . ($product_info['price'] * $product_info['quantity']) . "</td>
                              <td>&nbsp;</td>
                              <td>&nbsp;</td>
                            </tr>";
                  }
              } else {
                  echo "<tr><td colspan='7' class='text-center'>Your cart is empty</td></tr>";
              }
              ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <div class="row justify-content-end">
      <div class="mt-5 col col-lg-3 col-md-6 cart-wrap ftco-animate">
        <div class="mb-3 cart-total">
          <h3>Cart Totals</h3>
          <p class="d-flex">
            <span>Subtotal</span>
            <span>shs
              <?php
              // Get total amount from session
              echo isset($_SESSION['item_total']) ? $_SESSION['item_total'] : '0';
              ?>
            </span>
          </p>
          <p class="d-flex">
            <span>Quantity Bought</span>
            <span>
              <?php
              // Get quantity from session
              echo isset($_SESSION['item_quantity']) ? $_SESSION['item_quantity'] : '0';
              ?>
            </span>
          </p>
          <p class="d-flex">
            <span>Discount</span>
            <span>shs</span> <!-- Add discount logic if needed -->
          </p>
          <hr>
          <p class="d-flex total-price">
            <span>Total</span>
            <span>shs
              <?php
              // Calculate and show total amount including VAT and delivery charge
              $total_amount = $_SESSION['item_total'] + 50 - 0 + 100;  // Add VAT and delivery charges
              $_SESSION['total_amount'] = $total_amount;
              echo $total_amount;
              ?>
            </span>
          </p>
        </div>

        <?php if (is_logged_in()) : ?>
          <form action="checkout.php" method="POST">
            <div class="form-group">
              <label for="name">Full Name</label>
              <input type="text" name="name" class="form-control" required>
            </div>
            <div class="form-group">
              <label for="email">Email</label>
              <input type="email" name="email" class="form-control" required>
            </div>
            <div class="form-group">
              <label for="address">Address</label>
              <input type="text" name="address" class="form-control" required>
            </div>
            <div class="form-group">
              <label for="payment_method">Payment Method</label>
              <select name="payment_method" class="form-control" required>
                <option value="mobile_money">Mobile Money</option>
                <option value="credit_card">Credit Card</option>
              </select>
            </div>
            <p class="text-center">
              <!-- <button type="submit" class="px-4 py-3 btn btn-primary">Proceed to Checkout</button> -->
              <a class="px-4 py-3 btn btn-primary" href="shopping-cart-form.php" target="_blank" rel="noopener noreferrer">Checkout</a>
            </p>
          </form>
        <?php else : ?>
          <p class="text-center"><a href="login.php" class="px-4 py-3 btn btn-danger">Login to Checkout</a></p>
        <?php endif; ?>

      </div>
    </div>
  </div>
</section>

<?php include('footer.php'); ?>

<!-- Loading animations -->
<div id="ftco-loader" class="show fullscreen">
  <svg class="circular" width="48px" height="48px">
    <circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee" />
    <circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00" />
  </svg>
</div>

<script src="js/jquery.min.js"></script>
<script src="js/jquery-migrate-3.0.1.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="js/jquery.waypoints.min.js"></script>
<script src="js/jquery.stellar.min.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/jquery.magnific-popup.min.js"></script>
<script src="js/aos.js"></script>
<script src="js/jquery.animateNumber.min.js"></script>
<script src="js/bootstrap-datepicker.js"></script>
<script src="js/jquery.timepicker.min.js"></script>
<script src="js/scrollax.min.js"></script>
<script src="js/main.js"></script>
</body>
</html>
