<?php
class OrderTransaction {
    public function saveTransactionQuery($post_data) {
        // Prepare all fields for the 'orders' table
        $data = [
            'identify_num'    => $this->sanitize($post_data['customer_identify_num'] ?? ''),
            'cus_id'          => (int)($post_data['customer_id'] ?? 0),
            'cus_name'        => $this->sanitize($post_data['customer_name'] ?? ''),
            'cus_email'       => $this->sanitize($post_data['customer_email'] ?? ''),
            'order_date'      => date('Y-m-d H:i:s'),
            'order_pin_code'  => $this->sanitize($post_data['customer_pin_code'] ?? ''),
            'total_amount'    => (float)($post_data['total_amount'] ?? 0),
            'total_quantity'  => (int)($post_data['items'] ?? 0),
            'status'          => 'Pending',
            'transaction_id'  => $this->sanitize($post_data['transaction_id'] ?? 'FLW-' . uniqid()),
            'delivery_status' => 'Not Assigned',
            'driver_id'       => 0
        ];

        return "INSERT INTO orders (
                    identify_num, cus_id, cus_name, cus_email, 
                    order_date, order_pin_code, total_amount, 
                    total_quantity, status, transaction_id, 
                    delivery_status, driver_id
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    }

    private function sanitize($data) {
        return htmlspecialchars(stripslashes(trim($data ?? '')));
    }
}