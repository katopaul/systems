<?php
include(__DIR__ . "/../vendor/autoload.php");

// Create a .env and .env.example file in the config folder
// NOTE: These files can appear multiple times in different directories

$dotenv = Dotenv\Dotenv::createUnsafeImmutable(__DIR__);
$dotenv->load();

// Pesapal API Credentials from .env
$CONSUMER_KEY = getenv('Pesapal_Consumer_Key');
$CONSUMER_SECRET = getenv('Pesapal_Consumer_Secret');

// Define Pesapal endpoint URL (sandbox or live)
if (!defined('PESAPAL_API_URL')) {
    define('PESAPAL_API_URL', 'https://www.pesapal.com/API/PostPesapalDirectOrderV4'); // Update this to live URL when you go live
}

if (!defined('IS_LOCALHOST')) {
    define('IS_LOCALHOST', true); // Change it to false for live server
}

// Define the project path (use localhost or live URL)
if (!defined('PROJECT_PATH')) {
    define('PROJECT_PATH', 'http://localhost/pesapal-integration/'); // Use your actual localhost path
}

// Define Pesapal credentials from .env
if (!defined('PESAPAL_CONSUMER_KEY')) {
    define('PESAPAL_CONSUMER_KEY', $CONSUMER_KEY); // From your Pesapal account
}

if (!defined('PESAPAL_CONSUMER_SECRET')) {
    define('PESAPAL_CONSUMER_SECRET', $CONSUMER_SECRET); // From your Pesapal account
}

return [
    'projectPath' => constant("PROJECT_PATH"),
    'apiDomain' => constant("PESAPAL_API_URL"),
    'apiCredentials' => [
        'consumer_key' => constant("PESAPAL_CONSUMER_KEY"),
        'consumer_secret' => constant("PESAPAL_CONSUMER_SECRET"),
    ],
    'apiUrl' => [
        'make_payment' => "/API/PostPesapalDirectOrderV4", // API URL to initiate payment
        'transaction_status' => "/API/QueryPaymentStatus", // URL to check transaction status
    ],
    'connect_from_localhost' => constant("IS_LOCALHOST"),
    'success_url' => 'pg_redirection/success.php', // Redirect for success payment
    'failed_url' => 'pg_redirection/fail.php',
    'cancel_url' => 'pg_redirection/cancel.php',
    'ipn_url' => 'pg_redirection/ipn.php',
];
